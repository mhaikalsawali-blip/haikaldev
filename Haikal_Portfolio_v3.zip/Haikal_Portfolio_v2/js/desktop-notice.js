/* Pemberitahuan fokus desktop: popup di layar < 1024px, toast di desktop. Muncul setelah welcome screen selesai, sekali per sesi. */
(function(){var n=document.getElementById('dn'),t=document.getElementById('dnT'),p=document.getElementById('dnP'),b=document.getElementById('dnOk'),d=document.documentElement,last=null;if(!n)return;
try{if(sessionStorage.getItem('hs_dn')==='1')return}catch(e){}
function open(){var sm=innerWidth<1024;n.classList.toggle('dn-toast',!sm);
if(sm){n.setAttribute('role','dialog');n.setAttribute('aria-modal','true');t.textContent='Dioptimalkan untuk Desktop';p.textContent='Portofolio ini memakai tata letak layar lebar, efek visual interaktif, dan musik latar yang paling nyaman dinikmati di PC/Laptop. Gunakan perangkat desktop untuk pengalaman terbaik.';b.textContent='Mengerti & Lanjutkan';d.classList.add('dn-lock')}
else{n.setAttribute('role','status');n.removeAttribute('aria-modal');t.textContent='Mode Fokus Desktop';p.textContent='Tampilan ini dioptimalkan untuk desktop. Klik tombol speaker di kanan bawah untuk menyalakan musik latar.';b.textContent='Tutup'}
last=document.activeElement;n.hidden=false;void n.offsetWidth;n.classList.add('dn-show');if(sm)n.querySelector('.dn-card').focus({preventScroll:true})}
function close(){if(n.hidden)return;n.classList.remove('dn-show');d.classList.remove('dn-lock');try{sessionStorage.setItem('hs_dn','1')}catch(e){}setTimeout(function(){n.hidden=true},350);try{last&&last.focus&&last.focus({preventScroll:true})}catch(e){}}
b.addEventListener('click',close);n.addEventListener('click',function(e){if(e.target===n&&!n.classList.contains('dn-toast'))close()});
addEventListener('keydown',function(e){if(e.key==='Escape'&&!n.hidden)close()});
function go(){setTimeout(open,350)}
if(d.classList.contains('wl-on')){var mo=new MutationObserver(function(){if(!d.classList.contains('wl-on')){mo.disconnect();go()}});mo.observe(d,{attributes:true,attributeFilter:['class']})}else go();
})();
