(function(){var d=document.documentElement,w=document.getElementById('welcome');if(!w||!d.classList.contains('wl-on'))return;
var ws=w.querySelector('.wl-ws'),pc=w.querySelector('.wl-ws__val'),
rd=window.matchMedia&&matchMedia('(prefers-reduced-motion:reduce)').matches,MIN=rd?600:1900,MAX=2500,t0=Date.now(),done=false;
/* WakeSlider (versi vanilla): bar mengikuti nilai dengan spring, gelombang "wake" muncul saat bergerak cepat */
var W=(function(tr,rd){var N=32,REST=12/56,SENS=3,REACH=6,SKEW=.6,w0=9.23/.3,wv=20,tg=0,x=0,v=0,sp=0,sv=0,la=0,run=true,last=0,bars=[];
for(var i=0;i<N;i++){var b=document.createElement('span');b.className='wl-ws__bar';tr.appendChild(b);bars.push(b)}
function paint(force){var h=(rd?tg:x)/100*(N-1),vv=rd?0:sp,t=Math.min(1,Math.abs(vv)*SENS/320),amp=t*t*(3-2*t),dir=Math.sign(vv)||1,r=1.5+(REACH-1.5)*amp,bh=r*(1+SKEW),ah=r*(1-.5*SKEW),lit=Math.round(h),flat=!force&&amp<.002&&la<.002;
for(var i=0;i<N;i++){var e=bars[i],on=i<=lit?'true':'false';if(e.dataset.on!==on)e.dataset.on=on;if(flat)continue;var d=i-h,R=d*dir<0?bh:ah,lift=Math.abs(d)<R?amp*Math.pow(Math.cos(Math.PI*d/(2*R)),2):0;e.style.transform='scaleY('+(REST+lift*(1-REST))+')'}la=amp}
function loop(now){if(!run)return;var dt=Math.min(.05,(now-last)/1000||0),n,hh,k;last=now;if(!rd){n=Math.max(1,Math.ceil(dt/.004));hh=dt/n;for(k=0;k<n;k++){v+=(w0*w0*(tg-x)-2*w0*v)*hh;x+=v*hh;sv+=(wv*wv*(v-sp)-2.5*wv*sv)*hh;sp+=sv*hh}}paint();requestAnimationFrame(loop)}
paint(true);requestAnimationFrame(function(t){last=t;loop(t)});
return{set:function(p){tg=p},stop:function(){run=false}}})(w.querySelector('.wl-ws__track'),rd);
function set(p){var n=Math.round(p*100);W.set(n);pc.textContent=n+'%';ws.setAttribute('aria-valuenow',n)}
function finish(){if(done)return;done=true;set(1);
setTimeout(function(){w.classList.add('wl-out');var m=document.getElementById('main');if(m&&m.className==='pg'){m.className='';void m.offsetWidth;m.className='pg'}
try{sessionStorage.setItem('hs_welcome','1')}catch(e){}
setTimeout(function(){d.classList.remove('wl-on');w.hidden=true;W.stop()},750)},rd?0:380)}
function tick(){if(done)return;var e=Date.now()-t0,x=Math.min(1,e/MIN),ok=document.readyState==='complete';
set((.5-.5*Math.cos(Math.PI*x))*(ok?1:.96));if(e>=MAX||(ok&&e>=MIN))return finish();requestAnimationFrame(tick)}
set(0);requestAnimationFrame(tick);setTimeout(finish,MAX+150);
w.addEventListener('click',finish);addEventListener('keydown',function(e){if(e.key==='Escape')finish()});
})();
