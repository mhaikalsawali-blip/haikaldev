/* Musik latar untuk seluruh portofolio. Ganti lagu: timpa assets/musik-portofolio.mp3. Volume: ubah V (0-1). */
(function(){var a=document.getElementById('bgm'),b=document.getElementById('mu');if(!a||!b)return;
var V=.5,want=true,fd=0,rs=false,ev=['pointerup','touchend','click','keydown'];
try{if(sessionStorage.getItem('hs_music')==='0')want=false}catch(e){}
function pref(v){try{sessionStorage.setItem('hs_music',v)}catch(e){}}
function ui(){var on=!a.paused;b.setAttribute('aria-pressed',on);b.setAttribute('aria-label',on?'Jeda musik':'Putar musik')}
function ramp(){clearInterval(fd);fd=setInterval(function(){var v=Math.min(V,a.volume+V/18);a.volume=v;if(v>=V)clearInterval(fd)},70)}
function play(){var p;try{a.volume=0;p=a.play()}catch(e){return}if(p&&p.then)p.then(function(){ramp();unarm()},function(){})}
function gest(e){if(b.contains(e.target)||!want||!a.paused)return;play()}
function arm(){ev.forEach(function(t){document.addEventListener(t,gest,true)})}
function unarm(){ev.forEach(function(t){document.removeEventListener(t,gest,true)})}
a.addEventListener('play',ui);a.addEventListener('pause',ui);a.addEventListener('error',function(){b.hidden=true;unarm()});
if(a.error)b.hidden=true;
b.addEventListener('click',function(){if(a.paused){want=true;pref('1');play()}else{want=false;pref('0');a.pause()}});
document.addEventListener('visibilitychange',function(){if(document.hidden){if(!a.paused){rs=true;a.pause()}}else if(rs){rs=false;if(want)play()}});
ui();if(want){arm();play()}
})();
