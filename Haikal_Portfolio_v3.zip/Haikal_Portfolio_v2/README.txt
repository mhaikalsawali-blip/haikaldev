HAIKAL.DEV — PORTFOLIO

Cara membuka:
1. Ekstrak ZIP ini.
2. Buka folder Haikal_Portfolio di Acode.
3. Buka index.html lalu pilih Preview / Open in Browser.

Foto profil About tersimpan di assets/foto-haikal.jpg. Foto memakai gaya hitam-putih berbentuk lingkaran dengan cincin gradasi seperti kaset.

Catatan: Beberapa font/ikon memakai resource online sehingga internet mungkin diperlukan. Form kontak membuka draf di aplikasi email; pesan terkirim setelah tombol Send ditekan di aplikasi email.

WELCOME SCREEN
Layar loading hitam muncul sekali per sesi browser (sekitar 2 detik), lalu memudar ke halaman utama.
Kode: css/style.css (komentar "Welcome screen"), id="welcome" di index.html, dan js/welcome.js.
Ubah durasi di js/welcome.js: MIN (minimal, ms) dan MAX (batas maksimal, ms). Ketuk layar atau tekan Esc untuk melewati.
Menampilkan ulang saat testing: tutup tab lalu buka lagi (sessionStorage dihapus saat tab ditutup).

MUSIK LATAR
Lagu ada di assets/musik-portofolio.mp3 dan berulang otomatis. Browser biasanya memblokir suara otomatis,
jadi musik mulai pada ketukan pertama di halaman. Tombol bulat di kanan bawah untuk jeda/putar.
Ganti lagu: timpa file tersebut (nama sama). Atur volume: ubah nilai V di js/music.js (0 sampai 1).

BACKGROUND & PROGRESS LOADING
Background welcome memakai assets/dark-veil.jpg (render DarkVeil) dengan gerak halus CSS. Ganti gambar: timpa file itu.
Garis progress memakai WakeSlider versi vanilla (32 bar). Pengaturan ada di js/welcome.js (WakeSlider): N, SENS, REACH, SKEW.

PEMBERITAHUAN FOKUS DESKTOP
Muncul setelah welcome selesai, sekali per sesi: popup di layar < 1024px, toast di desktop.
Kode ada di js/desktop-notice.js dan css/style.css (komentar "Pemberitahuan fokus desktop"). Ubah batas layar di script: innerWidth<1024.
Untuk menghapus: hapus blok CSS, elemen id="dn", dan script tersebut.

STRUKTUR FILE
index.html          markup
css/style.css       semua gaya
js/app.js           logika utama (routing, data proyek & sertifikat)
js/welcome*.js      welcome screen + progress
js/music.js         musik latar (tombol putar/jeda manual tersedia)
js/desktop-notice.js
assets/             gambar & musik (sudah dikompres)
