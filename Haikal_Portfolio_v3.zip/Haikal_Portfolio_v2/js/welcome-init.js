/* Welcome screen: tampil sekali per sesi; aman jika sessionStorage tidak tersedia */
(function(){var d=document.documentElement,s=0;try{s=sessionStorage.getItem('hs_welcome')==='1'}catch(e){}if(!s){d.classList.add('wl-on');setTimeout(function(){d.classList.remove('wl-on')},4500)}})();
